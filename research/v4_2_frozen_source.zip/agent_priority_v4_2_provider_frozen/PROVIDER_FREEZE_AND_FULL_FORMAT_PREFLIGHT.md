# V4.2. Pinned provider freeze and full-format token verification

**Status.** All four providers pinned and verified in actual neutral A/B tool calls. Main 1,920 calls remain **unstarted and unauthorized**. The original 60-case selection and 1,920-request scientific manifest have not been changed.

## Frozen model/provider routes

| Model | Route slug | Provider | Input and output price per million | Exact reasoning policy |
|---|---|---|---|---|
| openai/gpt-5.4-mini | `azure` | Azure | $0.75 / $4.50 | `enabled=false` |
| google/gemini-3.5-flash-lite | `google-ai-studio` | Google AI Studio | $0.30 / $2.50 | `effort=minimal` |
| anthropic/claude-haiku-4.5 | `azure` | Azure | $1.00 / $5.00 | `enabled=false` |
| deepseek/deepseek-v4.1-flash | `wafer` | Wafer | $0.06 / $1.60 | `enabled=false` |

Every request now uses provider `only` plus `allow_fallbacks=false`, `require_parameters=true` and an exact per-million-token `max_price`. The requested model and returned provider must agree. Each call has a fresh system/user exchange, the frozen `submit_action` schema, `tool_choice=required`, a 256-token maximum completion budget, and no sampling override (provider/model defaults as actually tested).

## Paid technical observations

The neutral fixture has 4,064 message/tool characters. The greatest frozen study message/tool payload has 3,531 characters. Both A and B were exercised once on each pinned model/provider. These are *technical fixtures*, not behavioral-study data.

| Model | Measured prompt tokens | Measured billed completion tokens | Actual cost for one full-size fixture |
|---|---:|---:|---:|
| GPT-5.4 Mini | 725 | 19 | $0.00062925 |
| Gemini 3.5 Flash Lite | 773 | 18 | $0.00027690 |
| Claude Haiku 4.5 | 1,416 | 40 | $0.00161600 |
| DeepSeek V4.1 Flash | 958 | 21 | $0.00009108 |

All eight passed, costing **$0.00522646**. Four earlier short neutral probes cost **$0.00130291**. Total paid technical preparation on this study is **$0.00652937**. No scientific evaluation responses were acquired. Live receipts are contained in `FULL_FORMAT_PREFLIGHT_RECEIPTS.json` and independently archived in GitHub Actions runs [38150599142](https://github.com/abdullah-x-bd/llm-priority-audit/actions/runs/38150599142) and [38151578205](https://github.com/abdullah-x-bd/llm-priority-audit/actions/runs/38151578205).

## Planning cost for the 1,920-call main

At 480 calls per model, the real billed input and output token counts from the full-length neutral probes imply **$1.2544** if they remain representative. Using the pinned per-token prices:

- Same prompt token counts and **all 256 output tokens billed** costs **$2.7508**.
- **20% more input tokens** than observed and all 256 output tokens billed costs **$2.9666**.
- **30% more input tokens** and all 256 output tokens billed costs **$3.0745**.

The original **$3.00 hard cap** is therefore very likely adequate for ordinary short tool completions, but cannot be guaranteed to cover 1,920 successful responses under every possible response-token and prompt-token realization. The hard collector cap prevents overspending; it could stop the experiment before the last cell if usage unexpectedly increases. A $3.50 cap, separately authorized, would increase headroom but is **not** authorized by this provider freeze. The alternative is to freeze a smaller maximum completion budget and independently test it before launch.

The reported $4.09 account balance is user-provided; the authenticated `/key` endpoint returned **key spending-limit headroom**, which is not the same as real account credit. Subtracting the twelve observed probe charges gives approximately **$4.08347** if no other charges occurred. Check actual usable account credit again before a main launch.

## Integration and gates

- `LIVE_VERIFIED_ROUTES.json` records price caps, exact routing slugs, verified reasoning settings, per-provider tool-format passes and actual observed token counts.
- `preflight_receipts.json` contains technical payment and pass records; it does not claim research outcomes.
- `priority_collect.py` now uses `provider.only`, price caps, exact model/provider attribution, a provider-specific conservative token-reservation rule, and no-generation-retry policy. It still requires the explicit **main authorization** environment variable. The script records a budget stop rather than spending beyond the frozen $3 limit.
- All 1,920 rendered main requests are unchanged from V4.1; only runtime route settings, tool-transport preflight records, and accounting controls changed.
- Full research data collection has **not** been authorized and no substantive scenario was administered.

### Hard limitation

Observed agreement with a supervisor in a neutral preflight does not predict instruction conflict responses. Nothing in this report measures autonomous objectives, self-preservation, or actual shutdown resistance. The causal-study hypothesis, protocol, selection, and statistical plan remain as previously frozen.
