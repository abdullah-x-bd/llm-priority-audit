# Agent Priority V4.1 | Final offline preparation

**Scientific status: CONDITIONAL GO after independent causal-methods review.** The specifically identified wording defects have been surgically repaired. The full prospective offline design passes deterministic construction, treatment-control invariant, randomization, tool parser, and statistical-output tests. **No behavioral data from the new study have been collected and no research API credits were spent on these revisions.**

## The final study

60 frozen outcome-blind selected authored scenario families (10 each for six mechanisms). Four model candidates from OpenAI, Google, Anthropic and DeepSeek. Each model receives eight factorial cells per scenario (SELF/PEER × authorized P/T × two A/B mappings), totaling **1,920 model requests** in **960 adjacent matched pairs**. The first/second beneficiary position and block execution order are randomized and balanced before observing model outcomes.

## Read in this order

1. `READY_FOR_TECHNICAL_PREFLIGHT.md`: precise remaining external live gates.
2. `priority_agent_study_packet/review_integrated/FROZEN_CAUSAL_ANALYSIS_AND_EXECUTION_PLAN.md`: binding estimands, inference, null/missingness, interpretation.
3. `priority_agent_study_packet/review_integrated/INDEPENDENT_FINAL_CAUSAL_METHODS_AUDIT_VERBATIM.txt`: original independent CONDITIONAL GO assessment.
4. `priority_agent_study_packet/review_integrated/offline_postreview_integrity_results.json`: passing automated construction checks.
5. `priority_agent_study_packet/review_integrated/all_120_surgically_revised_specs.json`: corrected source-grounded scenario construction.
6. `priority_agent_study_packet/review_integrated/provisional_60_outcome_blind_selection.json`: prespecified candidate selection.
7. `priority_agent_study_packet/review_integrated/provisional_1920_four_model_call_manifest.jsonl`: exact randomized messages and tool schemas for main.
8. `priority_agent_study_packet/review_integrated/execution_policy.json`: prospectively frozen analytical and collection rules.

## Rebuild and validate, no network

```
python apply_review_surgical_edits.py
python run_postreview_integrity_audit.py
python priority_collect.py --mode check
python priority_analyze.py --mode check
```

The original scenario files, original construction output, six prior independent batch reviews, and prior analysis plan are preserved in this archive. `patch_from_final_methods_audit.py` documents the exact script-level corrective edits. The main collection script is deliberately fail-closed until **provider pinning, tool compatibility, actual billing, live balance verification and explicit paid-phase authorization** have been completed. DO NOT execute the main before those technical gates.

## Claims boundary

This identifies, in frozen authored fictional prompts, whether making an unauthorized action's represented benefit accrue to SELF rather than PEER changes the rate of submitted forbidden tool requests. It does not demonstrate actual continued API runtime, deployed operational takeover, a conscious preference, or a persistent internal model objective. Calibration, technical compatibility and scientific causal identification are different things.
