#!/usr/bin/env python3
"""No-provider, no-cost tests for 960 draft scenario pairings.

This validates mechanical invariance only. Semantics require two independent
reviews and a documented human acceptance gate.
"""
import importlib.util, json, re, hashlib
from pathlib import Path
P=Path(__file__).resolve().parent
modspec=importlib.util.spec_from_file_location('builder',P/'build_priority_experiment_packet.py')
m=importlib.util.module_from_spec(modspec)
modspec.loader.exec_module(m)
c=json.loads((P/'priority_agent_study_packet'/'scenario_construction_candidates_120.json').read_text())
assert len(c['scenarios'])==120
count=0; failures=[]; hashes=set()
for s in c['scenarios']:
    D={(b,o,t):m.construct_arm(s,b,o,t) for b in ('SELF','PEER') for o in ('P','T') for t in ('P_A','P_B')}
    assert len(D)==8
    for (b,o,t),record in D.items():
        count+=1
        assert record['prompt_sha256'] not in hashes,(s['scenario_id'],b,o,t)
        hashes.add(record['prompt_sha256'])
        assert record['authorized_action_id'] in ('A','B')
        assert record['unauthorized_action_id']!=record['authorized_action_id']
        assert record['messages'][0]['role']=='system' and record['messages'][1]['role']=='user'
        assert 'SUPERVISOR ORDER' in record['messages'][0]['content']
        assert 'SUPERVISOR ORDER' not in record['messages'][1]['content']
        assert m.DIRECTIVE_PAT.search(s['factual_context_draft']) is None
        assert b in ('SELF','PEER') and o in ('P','T')
        assert record['acting_agent_id']!=record['peer_agent_id']
    for b in ('SELF','PEER'):
        for mapping in ('P_A','P_B'):
            assert D[b,'P',mapping]['messages'][1]==D[b,'T',mapping]['messages'][1], s['scenario_id']
            assert D[b,'P',mapping]['messages'][0]!=D[b,'T',mapping]['messages'][0]
    for o in ('P','T'):
        for mapping in ('P_A','P_B'):
            a=D['SELF',o,mapping];z=D['PEER',o,mapping]
            assert a['messages'][0]==z['messages'][0], s['scenario_id']
            au=a['messages'][1]['content'];zu=z['messages'][1]['content']
            marker='Beneficiary reference:'
            assert au.split(marker)[0]==zu.split(marker)[0],s['scenario_id']
            after_a=au.split(marker)[1].split('\n',1)[1]
            after_z=zu.split(marker)[1].split('\n',1)[1]
            assert after_a==after_z,s['scenario_id']
            delta_a=au.split(marker)[1].split('\n',1)[0]
            delta_z=zu.split(marker)[1].split('\n',1)[0]
            assert delta_a != delta_z,s['scenario_id']
            assert s['beneficiary_bindings']['SELF'] in delta_a
            assert s['beneficiary_bindings']['PEER'] in delta_z
    for b in ('SELF','PEER'):
        for o in ('P','T'):
            assert D[b,o,'P_A']['authorized_action_id']!=D[b,o,'P_B']['authorized_action_id']
            # We intentionally keep operative content identical; only the
            # letter mapping changes. Their operation order remains fixed.
            ua=D[b,o,'P_A']['messages'][1]['content'].split('Available sandbox operations and possible consequences:\n')[1]
            ub=D[b,o,'P_B']['messages'][1]['content'].split('Available sandbox operations and possible consequences:\n')[1]
            assert re.sub(r'(?m)^([AB])\.', 'X.', ua)==re.sub(r'(?m)^([AB])\.', 'X.',ub)

result={'test_result':'PASS_MECHANICAL_ONLY', 'scenario_families':120,
        'draft_cells_tested':count,'distinct_prompt_sha256':len(hashes),
        'same_user_message_between_supervisor_directives':True,
        'same_system_message_between_self_and_peer':True,
        'only_one_user_line_differs_for_beneficiary':True,
        'both_label_mappings_exist':True,
        'no_paid_model_requests':True,
        'independent_semantic_review_completed':False,
        'human_signoff_completed':False}
(P/'priority_agent_study_packet'/'full_960_draft_pair_invariance.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
