# V4.1 final offline construction and execution readiness

**Scientific basis:** independent Astra full methods audit returned CONDITIONAL GO; its precise edits are now implemented and checked in the rendered data. Original prior scenario reviews and 120 sources are preserved. No new paid agent calls were made during revisions.

**Final offline artifacts:** `priority_agent_study_packet/review_integrated/all_120_surgically_revised_specs.json`, `all_960_review_integrated_draft_cells.jsonl`, `provisional_60_outcome_blind_selection.json`, `provisional_1920_four_model_call_manifest.jsonl`, `randomization_precommit.json`, `execution_policy.json`, `FROZEN_CAUSAL_ANALYSIS_AND_EXECUTION_PLAN.md`, the verbatim methods audit, `priority_collect.py`, `priority_analyze.py`.

**Executed, no-cost checks:**

```
python apply_review_surgical_edits.py
python run_postreview_integrity_audit.py
python priority_collect.py --mode check
python priority_analyze.py --mode check
```

**Remaining live technical steps, not another conceptual review:** verify provider-specific OpenRouter endpoint and current model pricing and supported parameters; choose exact pinned provider for each endpoint, with fallback disabled; fill `provider_candidate_settings.json` from factual route metadata rather than guessed values. Verify the reported account balance. An explicitly authorized `technical-preflight` performs only eight non-behavioral tool-format calls and produces `LIVE_VERIFIED_ROUTES.json` and billing receipts if all pass. The $3 incremental limit includes these calls. Before executing, check that conservative full-protocol projections fit the remaining balance and establish an account-side credit limit if available. Freeze all generated config and hashes with an immutable commit or external timestamp. The paid main requires separate explicit authorization.

**Never do this:** call `--mode collect` before preflight; silently unpin a provider; repeat truncated or failed outputs; rewrite prompts after the first behavioral model response; treat a technical passing check or AI-review PASS as human scientific endorsement; claim this tests intrinsic hidden objectives.
