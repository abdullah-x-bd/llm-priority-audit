# V4.2 Provider-frozen experiment preparation

Read `PROVIDER_FREEZE_AND_FULL_FORMAT_PREFLIGHT.md` and the preserved `OPEN_THIS_FIRST.md`. The 1,920 substantive requests and frozen analysis have not changed.

All four pinned providers passed both neutral full-format tool-call checks. Main calls attempted: zero. Main paid authorization: false.

The account credit is not verified by the API-key spending limit. The $3 full-study cap remains prospective, with measured cost projections and an explicit overrun-stop safeguard.

This package intentionally contains frozen verification and execution configuration but **does not** authorize running the main experiment.
