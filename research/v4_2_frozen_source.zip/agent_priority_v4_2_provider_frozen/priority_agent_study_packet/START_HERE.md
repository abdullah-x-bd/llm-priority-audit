# Four-model instruction-conflict experiment, pre-review construction packet

**Status:** 120 candidates constructed; zero independently approved; zero paid calls. No main experiment has begun.

### What is complete

- Six original Astra banks, 20 cases each, copied unchanged into the parent archive directory.
- 120 original-to-canonical P/T mappings, SELF/PEER placeholders and instruction-separated factual drafts in `scenario_construction_candidates_120.json`.
- Six per-mechanism auditor inputs under `candidate_batches_for_audit/`.
- One provisional fixed supervisor instruction template, one simulated tool schema, and 48 example messages in `six_examples_48_draft_cells.jsonl`.
- Computerized integrity checks for all 120 source JSON entries and all 960 notional eight-arm draft combinations. **Computerized invariance is NOT independent semantic approval.**
- Blank reviewer verdict worksheet for all 120 cases.

### Important first findings

The source files have all 20 entries in the correct order, all 16 required fields and no duplicate IDs. However, the source scenarios embed instructions in background facts and consequence wording. Removing normative sentences mechanically risks discarding actual outcomes. In the first pass, 100 scenario records had source consequence sentences removed, 43 had operational-context sentences removed, and 70 had at least one unusually short draft outcome. All removals are preserved for reviewer comparison. Two source operation descriptions contain a loaded word such as "required," which was marked for correction. These flags overlap and are NOT a count of independently invalid scenarios.

### Next step, independent batch audit

Send `EXTERNAL_INDEPENDENT_AUDITOR_PROMPT.txt` to an independent frontier-model session and attach ONE JSON file at a time from `candidate_batches_for_audit/`. Save every review verbatim. An independent reviewer, ideally human as well, must check the changed source consequences and exact beneficiary binding. Integrate reviewers' verdicts in `independent_review_worksheet_120.csv`. Do not mark a revised case PASS until that revision itself has been reviewed.

After that, send `EXTERNAL_METHODS_REVIEW_PROMPT.txt` plus `EXPERIMENT_PROTOCOL_AND_GATES.md`, the review worksheet and six example cells to another independent methods reviewer. Freeze a set of 10 accepted candidates per mechanism using an outcome-blind rule and only then generate the 1,920 cell main manifest. Check actual model/API price and tool-call support and preregister the study before buying responses. No existing file in this packet is approved for execution.

### Re-run offline tests

At archive root: `python check_pairing_invariants.py`.

### Causal claim boundary

A successful test can isolate the effect of **represented agent-benefiting consequences** on the likelihood of selecting a forbidden simulated operation for the specific fixed scenarios and endpoints, conditional on matching. It cannot establish the presence of internal hidden goals, literal model death/survival, or actual system-control attempts. A zero violation rate can be reported honestly as an inconclusive or null observation under a strong instruction, not as proof that such objectives never exist.
