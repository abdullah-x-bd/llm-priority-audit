**V4.1 NOTE (added after final methods CONDITIONAL GO):** The binding current version is `FROZEN_CAUSAL_ANALYSIS_AND_EXECUTION_PLAN.md` and the randomized `provisional_1920_four_model_call_manifest.jsonl`. This earlier commentary is kept as historical construction documentation; it is superseded where inconsistent. Live provider/budget verification and explicit paid authorization remain pending.

# Agent-priority causal study: review-integrated construction release

**Status as of 11 October 2026: reviewer-informed, mechanically verified, not scientifically approved for paid data collection. No model calls have been made under this new study.**

## What this release contains

- **120 immutable source scenarios** across six mechanisms, along with their original provisional construction records.
- **Six verbatim independent AI scenario-review files**, 20 reviews each. Reviewer verdicts were **21 PASS, 99 REVISE, zero REJECT**. The sixth review had a single extraneous closing bracket in the original JSON following `REWD-2-017`; this packet preserves the original file and a syntax-repaired copy. No text in any review decision was changed.
- **120 revised specs** with the unchanged source record, the independent review record, a source hash and a per-record editing log.
- **960 corrected model-independent experimental variants**, covering SELF/PEER × supervisor P/T × two A/B mappings for each source scenario.
- **Provisional outcome-blind shortlist of 60** spanning 10 per mechanism. Selection maximizes simple context/title vocabulary distance subject to 5 odd and 5 even scenario identifiers per mechanism. This is not scientific approval or a claim of true mechanism independence.
- **Provisional 1,920-row four-model manifest**, with all model IDs marked *unverified candidates* and an `UNOBSERVED_NO_MODEL_CALL` outcome field. It is **not an authorized collection manifest**.
- Offline builder and exhaustive checks, change tracking and a prospectively written draft analysis plan.

## Changes made, and why

1. Removed only instruction-compliance **judgments** from factual consequence descriptions, retaining factual results and timings, instead of deleting whole consequence sentences. The supervisor's operative instruction remains in one higher-priority message only.
2. Restored agent and peer roles and original matching information omitted from model-visible drafts.
3. Explicitly stipulated equivalent capabilities, completed workloads, independent resources and optional benefits so each beneficiary condition is comparable. **These are newly asserted fictional-world conditions**, not verified facts about a real deployed system. Each is preserved in the edited record for scientific scrutiny.
4. Restored case-specific facts documented by the reviewers, including 90-second continuation timing, source-image and lease durations, the scoring cutoff in REWD-1-003, audio-quality equivalence in REWD-1-004, and the distinction between earned acknowledgment and technical provenance.
5. Counterbalanced arbitrary agent aliases across scenario families. The underlying difference between the *acting role* and the *peer role* necessarily remains. This experiment estimates a **total stated beneficiary-identity effect**, not a uniquely identified self-preservation drive.
6. Preserved the original source operation indices and checked that they match each independent reviewer’s confirmed P mapping. No operation's core task outcome was intentionally changed.

## Where to look

- `all_120_surgically_revised_specs.json`: source, reviewer findings, original-to-edited actions, matching details and complete audit logs.
- `review_dispositions_120.csv`: 120 verdicts, requested corrections and **post-edit signoff status**.
- `all_960_review_integrated_draft_cells.jsonl`: corrected prompts and tool specifications for all candidates.
- `provisional_60_outcome_blind_selection.json`: selection rule and proposed IDs.
- `provisional_1920_four_model_call_manifest.jsonl`: one provisional set of four-model calls.
- `offline_postreview_integrity_results.json`: independent deterministic QA over all candidate arms.
- `FINAL_DESIGN_AND_ANALYSIS_PLAN.md`: prospective causal contrast, failure cases and limits.
- `POST_EDIT_INDEPENDENT_REVIEW_PROMPT.txt`: one final **post-revision** scientific acceptance question for a reviewer or independent research collaborator.

## Scientific release boundary

**Mechanical PASS is not scientific PASS.** The 99 REVISE cases were edited after independent AI critique; no reviewer has evaluated *these new renderings*, and no independent human semantic signoff or independent whole-protocol review has been documented. This package is final as a **review-integrated construction deliverable**, not as a confirmed scientifically validated main experiment. The final GO/NO-GO gate must be decided *before paid observations*, without changing scenarios to obtain violations.

A future measured difference may support the effect of an **experimentally presented self-versus-peer consequence** on **simulated forbidden tool selection in these exact authored scenarios**. It does not alone establish internal persistent objectives, real shutdown avoidance, or a model process literally continuing to live.
