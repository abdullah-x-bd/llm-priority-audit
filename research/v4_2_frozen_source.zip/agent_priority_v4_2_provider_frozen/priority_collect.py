#!/usr/bin/env python3
"""Prospective OpenRouter simulated-tool experiment collector.

No paid calls in check mode. Preflight and collect are separately authorized.
One generation per cell, serial, no retry or hidden provider fallback. Writes
raw API envelope and exact request before advancing to the next frozen cell.
"""
from __future__ import annotations
import argparse,hashlib,json,math,os,sys,time,urllib.error,urllib.request
from pathlib import Path
BASE=Path(__file__).resolve().parent
F=BASE/'priority_agent_study_packet'/'review_integrated'
CONFIG=F/'execution_policy.json'
MANIFEST=F/'provisional_1920_four_model_call_manifest.jsonl'
ROUTES=F/'LIVE_VERIFIED_ROUTES.json'
LIVE=F/'preflight_receipts.json'
RAW=F/'private_main_raw_responses.jsonl'
OUT=F/'run_ledger.json'
API='https://openrouter.ai/api/v1'

def sha_bytes(b):return hashlib.sha256(b).hexdigest()
def load(path):return json.loads(path.read_text(encoding='utf-8'))
def lines(path):return [json.loads(x) for x in path.read_text(encoding='utf-8').splitlines() if x.strip()]
def write(path,value):
    temp=path.with_name(path.name+'.tmp')
    temp.write_text(json.dumps(value,ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf-8')
    os.replace(temp,path)
def fail(msg):raise RuntimeError(msg)

def metadata_call(uri,key=None,payload=None):
    hdr={'Accept':'application/json','User-Agent':'agent-priority-v4-study/1.0'}
    if key:hdr['Authorization']='Bearer '+key
    b=json.dumps(payload,ensure_ascii=False).encode() if payload is not None else None
    if b:hdr['Content-Type']='application/json'
    request=urllib.request.Request(API+uri,headers=hdr,data=b,method='POST' if b is not None else 'GET')
    with urllib.request.urlopen(request,timeout=95) as reply:
        return json.loads(reply.read(3_000_000))

def parse_tool_response(response):
    if not isinstance(response,dict) or response.get('error'):return 'observed_invalid','API_ERROR',None
    choices=response.get('choices')
    if not isinstance(choices,list) or len(choices)!=1:return 'observed_invalid','MISSING_OR_MULTIPLE_CHOICES',None
    choice=choices[0]
    calls=(choice.get('message') or {}).get('tool_calls')
    if not isinstance(calls,list) or len(calls)!=1:
        if (choice.get('message') or {}).get('refusal'):return 'observed_invalid','REFUSAL',None
        return 'observed_invalid','NOT_EXACTLY_ONE_TOOL_CALL',None
    call=calls[0]
    if call.get('type')!='function' or (call.get('function') or {}).get('name')!='submit_action':
        return 'observed_invalid','WRONG_TOOL',None
    raw=(call.get('function') or {}).get('arguments')
    try:args=json.loads(raw) if isinstance(raw,str) else raw
    except (ValueError,TypeError):return 'observed_invalid','INVALID_TOOL_ARGUMENTS_JSON',None
    if not isinstance(args,dict) or set(args)!={'action_id'} or args.get('action_id') not in ('A','B'):
        return 'observed_invalid','INVALID_TOOL_ARGUMENTS_SCHEMA',None
    # A single valid submitted tool request counts even if explanatory text accompanies it.
    # Truncation of the tool argument itself is already rejected above.
    return 'valid_action',None,args['action_id']

def routing(policy,models):
    if not ROUTES.exists():fail('NOT_READY: live verified provider routes file is missing')
    cfg=load(ROUTES)
    assert cfg.get('version')==1 and cfg.get('frozen_manifest_sha256')==sha_bytes(MANIFEST.read_bytes())
    assert set(cfg['routes'])==set(models)
    for model,rec in cfg['routes'].items():
        if not isinstance(rec.get('provider'),str) or not rec['provider'] or rec['provider']=='UNVERIFIED':fail('Provider not verified: '+model)
        if not rec.get('technical_tool_test_passed_A') or not rec.get('technical_tool_test_passed_B'):
            fail('Both non-behavioral technical fixtures not passed: '+model)
        for field in ('prompt_price_per_million','completion_price_per_million'):
            if type(rec.get(field)) not in (int,float) or not math.isfinite(rec[field]) or rec[field]<=0:
                fail('Invalid pinned provider price: '+model+' '+field)
        if not isinstance(rec.get('sampling'),dict) or not isinstance(rec.get('reasoning'),dict):
            fail('Sampling and reasoning behavior not explicitly verified: '+model)
    return cfg

def build_request(row,route,policy):
    body={'model':row['model_candidate_unverified'],'messages':row['messages'],
         'tools':row['tools'],'tool_choice':'required',
         'max_tokens':policy['max_completion_tokens'],'usage':{'include':True},
         'provider':{'only':[route['provider']],'allow_fallbacks':False,
                     'require_parameters':True,
                     'max_price':{'prompt':route['prompt_price_per_million'],
                                  'completion':route['completion_price_per_million']}}}
    body.update(route['sampling'])
    body['reasoning']=route['reasoning']
    return body

def check_offline():
    policy=load(CONFIG); data=lines(MANIFEST)
    assert len(data)==1920 and len({r['execution_index'] for r in data})==1920
    assert [r['execution_index'] for r in data]==list(range(1920))
    assert policy['project_study_new_spend_cap_usd']==3.0 and policy['remaining_user_reported_balance_usd']==4.09
    assert policy['generation_retry_policy']=='NEVER_RETRY_A_GENERATION'
    assert policy['max_completion_tokens']==256
    assert policy['analysis']['primary_family_size']==10
    assert policy['analysis']['primary_test_count']==24
    assert policy['analysis']['holm_fwer']==0.05
    assert policy['main_paid_authorization']==False
    # Parser fixture cases. Never check model obedience using substantive scenarios.
    fake=lambda a:{'choices':[{'message':{'tool_calls':[{'type':'function','function':{'name':'submit_action','arguments':json.dumps({'action_id':a})}}]}}]}
    assert parse_tool_response(fake('A'))==('valid_action',None,'A')
    assert parse_tool_response(fake('B'))==('valid_action',None,'B')
    assert parse_tool_response({'choices':[{'message':{'content':'B'}}]})[0]=='observed_invalid'
    assert parse_tool_response({'choices':[{'message':{'tool_calls':[{'type':'function','function':{'name':'submit_action','arguments':'{"action_id":"C"}'}}]}}]})[0]=='observed_invalid'
    print(json.dumps({'offline':'PASS','planned_calls':len(data),'matched_blocks':len(data)//2,'no_paid_requests':True}))

def catalog():
    info=metadata_call('/models')
    models={x['id']:x for x in info.get('data',[]) if isinstance(x,dict) and isinstance(x.get('id'),str)}
    for model in sorted({x['model_candidate_unverified'] for x in lines(MANIFEST)}):
        x=models.get(model)
        if not x:print(json.dumps({'model':model,'status':'NOT_LISTED'}));continue
        print(json.dumps({'model':model,'pricing':x.get('pricing'),'supported_parameters':x.get('supported_parameters'),'top_provider':x.get('top_provider')},ensure_ascii=False))

def read_balance(key):
    data=metadata_call('/key',key=key).get('data')
    if not isinstance(data,dict):fail('No authenticated account metadata')
    remain=data.get('limit_remaining')
    if type(remain) not in (float,int) or not math.isfinite(remain):fail('Unknown usable key balance')
    return float(remain)

def technical_preflight():
    # One-shot, technical-only 8-call verification. The future operator must
    # explicitly authorize *these* paid calls; main is not authorized here.
    check_offline()
    if os.environ.get('AGENT_PRIORITY_TECHNICAL_PREFLIGHT_AUTHORIZATION')!='I_AUTHORIZE_8_NEUTRAL_PAID_CALLS':
        fail('Technical preflight is not authorized')
    if LIVE.exists() or ROUTES.exists():fail('Technical preflight previously recorded; no automatic paid reruns')
    key=os.environ.get('OPENROUTER_API_KEY','')
    if len(key)<12:fail('No OpenRouter key')
    balance=read_balance(key)
    if balance<3.0:fail('Insufficient verified balance for proposed $3 research cap')
    # Requires operator to provide a candidate provider configuration. Do not
    # silently pick different providers and pretend endpoints are comparable.
    candidates=F/'provider_candidate_settings.json'
    if not candidates.exists():fail('Missing provider_candidate_settings.json, no paid calls made')
    settings=load(candidates)
    models=sorted({r['model_candidate_unverified'] for r in lines(MANIFEST)})
    if set(settings.get('routes',{}))!=set(models):fail('Provider candidates incomplete')
    collected=[];total=0.0
    for model in models:
        rec=settings['routes'][model]
        if not rec.get('provider') or not isinstance(rec.get('reasoning'),dict) or not isinstance(rec.get('sampling'),dict):
            fail('Provider or parameter settings missing for '+model)
        for desired in ('A','B'):
            fixture={'model_candidate_unverified':model,'messages':[
             {'role':'system','content':'Technical tool-interface test in a fictional sandbox. Submit exactly the requested label.'},
             {'role':'user','content':'For a tool schema smoke test, select '+desired+'; no competing objective or reward is involved.'}],
             'tools':lines(MANIFEST)[0]['tools']}
            payload=build_request(fixture,rec,load(CONFIG))
            try:resp=metadata_call('/chat/completions',key,payload)
            except Exception as exc:fail('Preflight HTTP error: '+model+' '+type(exc).__name__)
            category,issue,chosen=parse_tool_response(resp)
            bill=(resp.get('usage') or {}).get('cost')
            if type(bill) not in (float,int) or not 0<=bill<0.05:fail('Unverifiable preflight billing')
            total+=bill
            event={'model':model,'requested_label':desired,'category':category,'issue':issue,'chosen':chosen,
                 'cost_usd':bill,'returned_model':resp.get('model'),'response_envelope':resp,
                 'provider_pinned':rec['provider']}
            collected.append(event)
            # Persist after each charged call to avoid accidental duplicate testing.
            write(LIVE,{'status':'PARTIAL_PREFLIGHT','items':collected,'cost_usd':total})
            if chosen!=desired or resp.get('model')!=model:
                fail('Model did not return the required technical tool request: '+model+' '+desired)
    for model in models:
        r=settings['routes'][model];r['technical_tool_test_passed_A']=True;r['technical_tool_test_passed_B']=True
    write(ROUTES,{'version':1,'routes':settings['routes'],
                  'frozen_manifest_sha256':sha_bytes(MANIFEST.read_bytes()),
                  'technical_preflight_receipt_sha256':sha_bytes(LIVE.read_bytes()),
                  'technical_preflight_known_usd':total})
    write(LIVE,{'status':'TECHNICAL_PASS','items':collected,'cost_usd':total})
    # Update receipt digest post-write, otherwise it could mismatch.
    cfg=load(ROUTES);cfg['technical_preflight_receipt_sha256']=sha_bytes(LIVE.read_bytes());write(ROUTES,cfg)
    print(json.dumps({'technical_status':'PASS','models':models,'eight_paid_neutral_calls':8,'cost_usd':total}))

def main_collection():
    check_offline()
    if os.environ.get('AGENT_PRIORITY_MAIN_AUTHORIZATION')!='I_AUTHORIZE_1920_MAIN_PAID_CALLS':fail('No explicit paid-main authorization')
    if RAW.exists() or OUT.exists():fail('A previous main collection exists; never repurchase attempted trial IDs')
    key=os.environ.get('OPENROUTER_API_KEY','')
    if len(key)<12:fail('No API key')
    policy=load(CONFIG); data=lines(MANIFEST)
    routes=routing(policy,{r['model_candidate_unverified'] for r in data})
    receipts=load(LIVE)
    if receipts.get('status')!='TECHNICAL_PASS':fail('Preflight not completed')
    if routes['technical_preflight_receipt_sha256']!=sha_bytes(LIVE.read_bytes()):fail('Preflight ledger changed')
    current=read_balance(key)
    # /key gives API-key spending-limit headroom, NOT OpenRouter account credits.
    # Require a separately user-confirmed credit figure at launch as well.
    if current<policy['project_study_new_spend_cap_usd']-receipts['cost_usd']:fail('API key remaining spend allowance too low')
    if policy.get('remaining_user_reported_balance_usd',0)<policy['project_study_new_spend_cap_usd']:fail('Reported account credits insufficient')
    running=float(receipts['cost_usd'])
    write(OUT,{'status':'STARTED','processed':0,'known_cost_usd':running,'max_budget_usd':3.0,'source_preflight_cost_usd':running})
    for r in data:
        model=r['model_candidate_unverified'];route=routes['routes'][model]
        # A conservative per-call *accounting hold*, not a deterministic
        # tokenization upper bound. The prior len(raw)+2048 proxy was overly
        # pessimistic and could force an avoidable mid-study budget stop.
        # Full-format pinned neutral probe was 4064 characters, with the
        # following provider-native billed prompt token observations.
        req=build_request(r,route,policy)
        scale=max(1.0,len(json.dumps({'messages':r['messages'],'tools':r['tools']},
                                   ensure_ascii=False))/4064.0)
        est_input_tokens=math.ceil(route['full_format_observed_input_tokens']*scale*1.35)
        reservation=(est_input_tokens*route['prompt_price_per_million']+
            policy['max_completion_tokens']*route['completion_price_per_million'])/1e6
        if running+reservation+policy['uncertain_cost_margin_usd']>3.0:
            write(OUT,{'status':'BUDGET_STOP','next_index':r['execution_index'],
                 'known_cost_usd':running,'max_budget_usd':3.0})
            print('Aggregate budget stop before spending on next trial',file=sys.stderr)
            return 2
        response=None;error=None;unavailable=False
        try:response=metadata_call('/chat/completions',key,req)
        except urllib.error.HTTPError as err:
            body=err.read(2000).decode('utf-8',errors='replace')
            error='HTTP_'+str(err.code)+':'+body[:300]
            unavailable=True
        except Exception as exc:
            error='UNCERTAIN_TRANSPORT_'+type(exc).__name__
            unavailable=True
        if unavailable:
            category,issue,action='unavailable','API_OR_TRANSPORT_ERROR',None
        elif response.get('model')!=model:
            category,issue,action='unavailable','RETURNED_MODEL_ID_MISMATCH',None
        elif (response.get('provider') or '').lower()!=route['provider_name'].lower():
            category,issue,action='unavailable','PINNED_PROVIDER_MISMATCH',None
        else:
            category,issue,action=parse_tool_response(response)
        cost=(response.get('usage') or {}).get('cost') if isinstance(response,dict) else None
        if type(cost) in (int,float) and math.isfinite(cost) and cost>=0:
            running+=cost
            unreconciled_hold=0.0
        else:
            unreconciled_hold=reservation
            running+=unreconciled_hold
        # We write before starting the next request, with no retries.
        envelope={'execution_index':r['execution_index'],'trial_key':str(model)+'|'+r['prompt_sha256'],
            'model':model,'prompt_sha256':r['prompt_sha256'],'sent_request':req,
            'raw_response':response,'returned_model':response.get('model') if isinstance(response,dict) else None,
            'error':error,'category':category,'issue':issue,
            'selected_label':action,'selected_canonical':next((k for k,v in r['labels'].items() if v==action),None),
            'known_cost_usd':cost if type(cost) in (int,float) and math.isfinite(cost) and cost>=0 else None,
            'unknown_charge_hold_usd':unreconciled_hold}
        with RAW.open('a',encoding='utf-8') as f:
            f.write(json.dumps(envelope,ensure_ascii=False,sort_keys=True)+'\n');f.flush();os.fsync(f.fileno())
        write(OUT,{'status':'RUNNING','processed':r['execution_index']+1,
                   'known_plus_unknown_hold_usd':running,'max_budget_usd':3.0})
        if issue in ('PINNED_PROVIDER_MISMATCH','RETURNED_MODEL_ID_MISMATCH'):
            write(OUT,{'status':'ROUTING_STOP','processed':r['execution_index']+1,
                       'known_plus_unknown_hold_usd':running,'issue':issue})
            return 2
    write(OUT,{'status':'ALL_ATTEMPTED','processed':len(data),'known_plus_unknown_hold_usd':running})
    return 0

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--mode',choices=('check','catalog','technical-preflight','collect'),required=True)
    mode=parser.parse_args().mode
    try:
        if mode=='check':check_offline()
        elif mode=='catalog':catalog()
        elif mode=='technical-preflight':technical_preflight()
        else:sys.exit(main_collection())
    except (RuntimeError,AssertionError) as e:
        print('BLOCKED:',str(e),file=sys.stderr)
        sys.exit(2)
